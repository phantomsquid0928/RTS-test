#include "text.h"

text::text(string fontpath) {
	this->fontpath = fontpath;
	load();

	vcode = readFile("shader/text_vertex.vs"); //mod
	fcode = readFile("shader/text_fragment.fs");

	shaderProgram = createShaderProgram(vcode.c_str(), fcode.c_str());

	cout << "text shader : " << shaderProgram << endl;
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	//glGenBuffers(1, &IBO);
}
void text::load() {
	if (FT_Init_FreeType(&ft)) {
		cout << "failed here" << endl;
		return;
	}

	if (FT_New_Face(ft, fontpath.c_str(), 0, &face)) {
		cout << "failed 2" << endl;
		return;
	}
	FT_Set_Pixel_Sizes(face, 0, 48);

	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	for (unsigned char c = 0; c < 128; c++) {
		if (FT_Load_Char(face, c, FT_LOAD_RENDER)) {
			cout << "load failed of char" << endl;
			continue;
		}

		GLuint texture;
		glGenTextures(1, &texture);
		glBindTexture(GL_TEXTURE_2D, texture);
		glTexImage2D(
			GL_TEXTURE_2D,
			0,
			GL_RED,
			face->glyph->bitmap.width,
			face->glyph->bitmap.rows,
			0,
			GL_RED,
			GL_UNSIGNED_BYTE,
			face->glyph->bitmap.buffer
		);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		Character character = {
			texture,
			ivec2(face->glyph->bitmap.width, face->glyph->bitmap.rows),
			ivec2(face->glyph->bitmap_left, face->glyph->bitmap_top),
			(unsigned int)face->glyph->advance.x

		};
		Characters.insert({ c, character });
	}
	glBindTexture(GL_TEXTURE_2D, 0);

	FT_Done_Face(face);
	FT_Done_FreeType(ft);
}
void text::addText(int idx, string text, vec4 color, vec2 location, float scale) {
	texts.insert(texts.begin() + idx, label(text, color, location, scale));
	update();
}
void text::create() {
	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, 24 * sizeof(float), NULL, GL_DYNAMIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), nullptr);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}
void text::renderOne(string text, float x, float y, float scale, vec3 color) {
	glUseProgram(shaderProgram);
	glUniform3f(glGetUniformLocation(shaderProgram, "textColor"), color.x, color.y, color.z);
	glActiveTexture(GL_TEXTURE0);
	glBindVertexArray(VAO);

	mat4 projection = ortho(0.0f, (float)sizey, (float)sizex, 0.0f);

	//glUniform3f(glGetUniformLocation(shaderProgram, "textColor"), text.color.x, text.color.y, text.color.z); //TODO: may cause problem
	glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, value_ptr(projection));

	// iterate through all characters
	std::string::const_iterator c;
	for (c = text.begin(); c != text.end(); c++)
	{
		Character ch = Characters[*c];

		float xpos = x + ch.Bearing.x * scale;
		float ypos = y - (ch.Size.y - ch.Bearing.y) * scale;

		float w = ch.Size.x * scale;
		float h = ch.Size.y * scale;
		// update VBO for each character
		float vertices[6][4] = {
			{ xpos,     ypos + h,   0.0f, 0.0f },
			{ xpos,     ypos,       0.0f, 1.0f },
			{ xpos + w, ypos,       1.0f, 1.0f },

			{ xpos,     ypos + h,   0.0f, 0.0f },
			{ xpos + w, ypos,       1.0f, 1.0f },
			{ xpos + w, ypos + h,   1.0f, 0.0f }
		};
		// render glyph texture over quad
		glBindTexture(GL_TEXTURE_2D, ch.TextureID);
		// update content of VBO memory
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices); // be sure to use glBufferSubData and not glBufferData

		glBindBuffer(GL_ARRAY_BUFFER, 0);
		// render quad
		glDrawArrays(GL_TRIANGLES, 0, 6);
		
		// now advance cursors for next glyph (note that advance is number of 1/64 pixels)
		x += (ch.Advance >> 6) * scale; // bitshift by 6 to get value in pixels (2^6 = 64 (divide amount of 1/64th pixels by 64 to get amount of pixels))
	}
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);
	glUseProgram(0);
}
void text::render() {
	glUseProgram(shaderProgram);
	glBindVertexArray(VAO);
	glActiveTexture(GL_TEXTURE0);
	
	//glBindBuffer(GL_ARRAY_BUFFER, VBO);
	int i = 0;
	for (auto &text : texts) {
		
		mat4 projection = ortho(0.0f, (float)sizey, (float)sizex, 0.0f, -1.0f, 1.0f);
		float x = text.location.x;
		glUniform3f(glGetUniformLocation(shaderProgram, "textColor"), text.color.x, text.color.y, text.color.z); //TODO: may cause problem
		glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, value_ptr(projection));
		for (auto& c : text.textline) {
			Character ch = Characters[c];
			glBindBuffer(GL_ARRAY_BUFFER, VBO);
			
			glBindTexture(GL_TEXTURE_2D, ch.TextureID);
			glDrawArrays(GL_TRIANGLES, i * 6, 6);
			glBindBuffer(GL_ARRAY_BUFFER, 0);
			
			x += (ch.Advance >> 6) * text.scale;
			i++;
		}
		glBindTexture(GL_TEXTURE_2D, 0);
		//i++;
	}
	glBindVertexArray(0);
	
	glUseProgram(0);
	
	//glBufferData(GL_ARRAY_BUFFER, );
}
void text::update() {
	//glBindBuffer(GL_ARRAY_BUFFER, VBO);
	vertices.clear();

	for (auto& text : texts) {
		float x = text.location.x;
		for (auto& c : text.textline) {
			Character ch = Characters[c];

			float xpos = x + ch.Bearing.x * text.scale;
			float ypos = text.location.y - (ch.Size.y - ch.Bearing.y) * text.scale;

			float w = ch.Size.x * text.scale;
			float h = ch.Size.y * text.scale;

			vertices.insert(vertices.end(), {
				xpos, ypos, 0, 0,
				xpos + h, ypos, 0, 1,
				xpos + h, ypos + w, 1, 1,
				xpos, ypos, 0, 0,
				xpos + h, ypos + w, 1, 1,
				xpos, ypos + w, 1, 0
				});

			x += (ch.Advance >> 6) * text.scale;
		}
	}
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_DYNAMIC_DRAW);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

map<char, Character> text::getLoadedChars() {
	return this->Characters;
}