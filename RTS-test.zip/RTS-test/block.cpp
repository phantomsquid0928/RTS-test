#include "block.h"

block::block() { //block default size is 1, position 0, 0
	vcode = readFile("mouse_vertex.glsl"); //modify by classes
	fcode = readFile("mouse_fragment.glsl");
	shaderProgram = createShaderProgram(vcode.c_str(), fcode.c_str());
	cout << "block shader : " << shaderProgram;

	size = 1;
}
void block::changepos(int posx, int posy) {
	this->posx = posx;
	this->posy = posy;
}

float vertices[12] = { 0.0f,  0.0f, 0.0f,  // Bottom left
		 1.0f,  0.0f, 0.0f,  // Bottom right
		 1.0f,  1.0f, 0.0f,  // Top right
		 0.0f,  1.0f, 0.0f   // Top left
};
void block::render() {
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glGenBuffers(1, &IBO);

	
	

	unsigned int indices[] = {
	   0, 1, 2,
	   2, 3, 0
	};

	glBindVertexArray(VAO);


	// VBO ���ε� �� ������ ����
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_DYNAMIC_DRAW);

	// EBO ���ε� �� ������ ����
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	// ���� �Ӽ� ������ ����
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// ���ε� ����
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
	//cout << VAO << VBO << IBO;
}

void block::update() { //made, changepos then update rendering

	// �簢�� ũ�� ������Ʈ
	float x1 = (2.0f * posx) / sizex - 1.0f;
	float y1 = 1.0f - (2.0f * posy) / sizey;
	float x2 = (2.0f * (posx + size)) / sizex - 1.0f;
	float y2 = 1.0f - (2.0f * (posy + size)) / sizey;

	vertices[0] = x1; vertices[1] = y1; // Bottom left
	vertices[3] = x2; vertices[4] = y1; // Bottom right
	vertices[6] = x2; vertices[7] = y2; // Top right
	vertices[9] = x1; vertices[10] = y2; // Top left

	//cout << x1 << y1 << "," << x2 << y2 << endl;
	// VAO, VBO ������Ʈ
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
	glBindBuffer(GL_ARRAY_BUFFER, 0);


	//cout << shaderProgram << endl;
	// ���̴� ���α׷� ���
	glUseProgram(shaderProgram);

	// VAO ���ε� �� �׸���
	glBindVertexArray(VAO);
	//glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
	//glDrawArrays(GL_LINE_LOOP, 0, 4);

	glBindVertexArray(0);
	glUseProgram(0);
}
mat4 block::getaabb() {

}