#pragma once
class Entity
{
public:
	void create();
	Entity();
	~Entity();
	
};

