#pragma once

#include "headers.hpp"
#include "../shader/shader.h"
#include "object.h"

class block : public shader, object
{
public:
	block();
	void render();
	void update();
	//void delta(int x, int y);
	mat4 getaabb();
	void changepos(int posx, int posy);
private:
	int size;
	int posx, posy;
};

